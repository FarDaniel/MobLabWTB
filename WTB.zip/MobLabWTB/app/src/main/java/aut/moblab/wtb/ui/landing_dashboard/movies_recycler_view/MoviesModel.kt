package aut.moblab.wtb.ui.landing_dashboard.movies_recycler_view

data class MoviesModel(
    val firstTitle: String,
    val firstImage: String,
    val firstId: String,
    val secondTitle: String? = null,
    val secondImage: String? = null,
    val secondId: String? = null
)