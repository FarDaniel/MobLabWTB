package aut.moblab.wtb.ui.lists

import android.util.Log
import aut.moblab.wtb.local_data.dao.MovieTagDao
import aut.moblab.wtb.local_data.models.MovieTag
import javax.inject.Inject

class ListsRepository @Inject constructor(val dao: MovieTagDao) {

    suspend fun getMovieTags(): List<MovieTag>{
        Log.d("MAKING", dao.getAllTag().toString())
        return dao.getAllTag()
    }

}
