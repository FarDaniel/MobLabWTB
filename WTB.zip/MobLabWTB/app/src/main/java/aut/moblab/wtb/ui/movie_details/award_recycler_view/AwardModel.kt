package aut.moblab.wtb.ui.movie_details.award_recycler_view

data class AwardModel(
    val title: String,
    val description: String
)
