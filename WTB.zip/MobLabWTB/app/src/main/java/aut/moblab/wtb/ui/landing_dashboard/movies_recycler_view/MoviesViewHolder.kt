package aut.moblab.wtb.ui.landing_dashboard.movies_recycler_view

import android.annotation.SuppressLint
import android.content.Context
import android.view.View
import androidx.recyclerview.widget.RecyclerView
import aut.moblab.wtb.databinding.ItemMoviePreviewBinding
import aut.moblab.wtb.ui.landing_dashboard.NavigationHelper
import com.bumptech.glide.Glide

class MoviesViewHolder(
    val binding: ItemMoviePreviewBinding,
    private val navigator: NavigationHelper
) :
    RecyclerView.ViewHolder(binding.root) {
    fun bind(model: MoviesModel, context: Context) {
        Glide.with(context)
            .load(model.firstImage)
            .into(binding.moviePreviewFirstImage)
        binding.moviePreviewFirstTitle.text = model.firstTitle

        if (model.secondImage.isNullOrEmpty()) {
            binding.moviePreviewSecondCard.visibility = View.INVISIBLE
            binding.moviePreviewSecondImage.visibility = View.INVISIBLE
        } else {
            binding.moviePreviewSecondCard.visibility = View.VISIBLE
            binding.moviePreviewSecondImage.visibility = View.VISIBLE
            Glide.with(context)
                .load(model.secondImage)
                .into(binding.moviePreviewSecondImage)
            binding.moviePreviewSecondTitle.text = model.secondTitle
        }
        initListeners(model)
        binding.executePendingBindings()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun initListeners(model: MoviesModel) {
        binding.moviePreviewFirstImage.setOnClickListener {
            navigator.watchDetails(model.firstId)
            true
        }
        binding.moviePreviewSecondImage.setOnClickListener {
            model.secondId?.let {
                navigator.watchDetails(it)
            }
            true
        }
        binding.moviePreviewFirstImage.setOnLongClickListener {
            navigator.addToWatched(model.firstId, model.firstTitle)
            true
        }
        binding.moviePreviewSecondImage.setOnLongClickListener {
            model.secondId?.let { id ->
                model.secondTitle?.let { title ->
                    navigator.addToWatched(id, title)
                }
            }
            true
        }
        binding.moviePreviewFirstImage.setOnLongClickListener {
                    navigator.addToWatched(model.firstId, model.firstTitle)
            true
        }
    }
}