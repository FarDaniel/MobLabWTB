package aut.moblab.wtb.ui.lists.tagged_movies_recycler_view

import androidx.recyclerview.widget.RecyclerView
import aut.moblab.wtb.databinding.ItemTitleBinding
import aut.moblab.wtb.local_data.models.MovieTag

class TaggedMovieViewHolder(val binding: ItemTitleBinding) : RecyclerView.ViewHolder(binding.root) {
    fun bind(tag: MovieTag) {
        binding.tag = tag
    }
}
