package aut.moblab.wtb.ui.landing_dashboard

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import aut.moblab.wtb.ui.landing_dashboard.movies_recycler_view.MoviesModel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class LandingViewModel @Inject constructor(private val repository: LandingRepository) :
    ViewModel() {

    val movies = MutableLiveData<List<MoviesModel>>()
    val taggedMovies = ArrayList<String>()

    init {
        viewModelScope.launch {
            repository.getMovieTags().forEach {
                taggedMovies.add(it.movieId)
            }
            repository.getMovies().collect { movieItems ->

                var firstTitle: String? = null
                var firstImage: String? = null
                var firstId: String? = null
                val array = ArrayList<MoviesModel>()
                var elementCnt = 0
                movieItems.movies.forEach { movie ->
                    elementCnt++
                    if (firstTitle.isNullOrEmpty()) {
                        if (!taggedMovies.contains(movie.movieId)) {
                            firstTitle = movie.title
                            firstImage = movie.image
                            firstId = movie.movieId
                        }
                    } else {
                        if (!taggedMovies.contains(movie.movieId)) {
                            firstTitle?.let { title ->
                                firstImage?.let { image ->
                                    firstId?.let { id ->
                                        array.add(
                                            MoviesModel(
                                                title,
                                                image,
                                                id,
                                                movie.title,
                                                movie.image,
                                                movie.movieId
                                            )
                                        )
                                    }
                                }
                            }
                            firstTitle = null
                            firstImage = null
                            firstId = null
                        }
                    }

                    if (elementCnt == movieItems.movies.size) {
                        if (!firstTitle.isNullOrEmpty()) {
                            firstTitle?.let { title ->
                                firstImage?.let { image ->
                                    firstId?.let { id ->
                                        array.add(
                                            MoviesModel(
                                                title,
                                                image,
                                                id
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }

                }
                if (movieItems.movies.size % 2 == 1) {
                    array.add(
                        MoviesModel(
                            movieItems.movies.last().title,
                            movieItems.movies.last().image,
                            movieItems.movies.last().movieId
                        )
                    )
                }
                movies.value = array
            }
        }
    }

    fun addMovieTag(movieId: String, title: String) {
        viewModelScope.launch {
            repository.addMovieTag(movieId, title)
        }
    }
}
