package aut.moblab.wtb.ui.landing_dashboard.movies_recycler_view

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import aut.moblab.wtb.databinding.ItemMoviePreviewBinding
import aut.moblab.wtb.ui.landing_dashboard.NavigationHelper

class MoviesAdapter(val context: Context, private val navigator: NavigationHelper) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    private var items: ArrayList<MoviesModel> = ArrayList()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)

        val binding = ItemMoviePreviewBinding.inflate(layoutInflater, parent, false)
        return MoviesViewHolder(binding, navigator)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val item = items[position]

        if (holder is MoviesViewHolder) {
            holder.bind(item, context)
        }
    }

    override fun getItemCount(): Int {
        return items.size
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun rearangeItems() {
        var i = 0
        items.forEach { movieModel ->
            if (movieModel.secondId == null && i != items.size - 1) {
                val first = items[i]
                val second = items[i + 1]
                items[i] = MoviesModel(
                    first.firstTitle,
                    first.firstImage,
                    first.firstId,
                    second.firstTitle,
                    second.firstImage,
                    second.firstId
                )
                for (j in i + 1 until items.size - 1) {
                    val actual = items[j]
                    val next = items[j + 1]
                    if (!actual.secondId.isNullOrEmpty() &&
                        !actual.secondTitle.isNullOrEmpty() &&
                        !actual.secondImage.isNullOrEmpty()
                    ) {
                        items[j] = MoviesModel(
                            actual.secondTitle,
                            actual.secondImage,
                            actual.secondId,
                            next.firstTitle,
                            next.firstImage,
                            next.firstId
                        )
                    }
                }
                return@forEach
            }
            i++
        }
        if (items.last().secondId.isNullOrEmpty()) {
            items.removeAt(items.lastIndex)
        } else {
            val last = items.last()
            if (!last.secondId.isNullOrEmpty() &&
                !last.secondTitle.isNullOrEmpty() &&
                !last.secondImage.isNullOrEmpty()
            ) {
                items[items.size - 1] = MoviesModel(
                    last.secondTitle,
                    last.secondImage,
                    last.secondId
                )
            }
        }
        notifyDataSetChanged()
    }

    fun addItems(moviesItems: List<MoviesModel>) {
        items.addAll(moviesItems)
    }

    fun removeItem(movieId: String) {
        for (i in 0 until items.size) {
            if (movieId == items[i].firstId) {
                val item = items[i]
                if (item.secondId == null) {
                    items.removeAt(i)
                    notifyItemRemoved(i)
                    rearangeItems()
                    return
                } else {
                    item.secondTitle?.let { title ->
                        item.secondImage?.let { image ->
                            items[i] = MoviesModel(
                                title,
                                image,
                                item.secondId
                            )
                        }
                    }
                }
            }
            if (movieId == items[i].secondId) {
                val item = items[i]

                items[i] = MoviesModel(
                    item.firstTitle,
                    item.firstImage,
                    item.firstId
                )
            }
        }
        rearangeItems()
    }
}
