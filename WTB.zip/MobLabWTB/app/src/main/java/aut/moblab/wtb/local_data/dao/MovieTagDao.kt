package aut.moblab.wtb.local_data.dao

import androidx.room.*
import aut.moblab.wtb.local_data.models.MovieTag

@Dao
interface MovieTagDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTag(movieTag: MovieTag): Long

    @Query("SELECT * FROM MovieTag")
    suspend fun getAllTag(): List<MovieTag>

    @Delete
    suspend fun deleteTag(tag: MovieTag)

}