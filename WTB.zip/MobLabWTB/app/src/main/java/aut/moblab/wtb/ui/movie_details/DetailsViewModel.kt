package aut.moblab.wtb.ui.movie_details

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import aut.moblab.wtb.network_data.models.Movie
import aut.moblab.wtb.ui.movie_details.award_recycler_view.AwardModel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DetailsViewModel @Inject constructor(private val repository: DetailsRepository) :
    ViewModel() {
    val awardModels = MutableLiveData<List<AwardModel>>()
    val movie = MutableLiveData<Movie>()

    fun loadAwards(movieId: String) {
        Log.d("MAKING", "loading details")
        viewModelScope.launch {
            val awards = ArrayList<AwardModel>()
            repository.getAwards(movieId).collect { awardItems ->
                awardItems.awards.forEach { awardEvent ->
                    awardEvent.details.forEach { actualAward ->
                        val title =
                            actualAward.category + " (${actualAward.outcome}) " + awardEvent.year
                        var description = ""
                        actualAward.details.forEach {
                            description += it.description + "\n\n"
                        }
                        awards.add(
                            AwardModel(
                                title = title,
                                description = description
                            )
                        )
                    }
                }
                awardModels.value = awards
            }
        }
    }

    fun loadMovie(movieId: String) {
        viewModelScope.launch {
            repository.getMovieDetails(movieId).collect {
                movie.value = it
            }
        }
    }

}
