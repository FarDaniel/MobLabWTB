package aut.moblab.wtb

import aut.moblab.wtb.network_data.models.Movie
import aut.moblab.wtb.network_data.models.MovieItems

object MovieGenerator {
    fun getMovies(cnt: Int): MovieItems {
        val movieItems = ArrayList<Movie>()
        for (i in 0 until cnt) {
            movieItems.add(
                Movie(
                    movieId = "" + i,
                    title = "Title $i",
                    image = "https://bmevik-redflags.herokuapp.com/api/catImage/$i"
                    )
            )
        }
        return MovieItems(movieItems)
    }
}
